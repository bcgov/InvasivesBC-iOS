//
//  OptionModel.swift
//  ipad
//
//  Created by Amir Shayegh on 2019-10-29.
//  Copyright © 2019 Amir Shayegh. All rights reserved.
//

import Foundation

enum OptionType {
    case Delete
    case Copy
    case Logout
}
